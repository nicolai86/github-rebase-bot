#!/bin/sh

set -x

branch="$1"
content="$2"
target="$3"

git checkout "$branch"
echo "$content" > "$target"
git add $target
git commit -m "generated commit"

git rev-parse HEAD
