#!/bin/sh

set -x

base="$1"
branch="$2"

git checkout $branch
git rebase $base -X theirs

git rev-parse HEAD
